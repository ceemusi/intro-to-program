
// This application performs arithmetic with two integers
public class DebugTwo2 {

	public static void main(String[] args) {
		// again going to rename the variables (a, b) for better naming convention
		int num1, num2;
		
		// declared the variables
		num1 = 7;
		num2 = 4;
		
		// enclosed the operators in brackets so the program can do the calculations
		System.out.println("The sum is "+(num1 + num2));
		System.out.println("The difference is "+(num1 - num2));
		System.out.println("The product is "+(num1 * num2));
	}

}
