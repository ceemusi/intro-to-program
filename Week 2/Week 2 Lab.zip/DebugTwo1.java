
public class DebugTwo1 {

	public static void main(String[] args) {
		
		//need to declare the int and double variables here, also changed variable names to be more simple
		final int num1 = 315;
		final double num2 = 12.4;
		
		//Typo in this line (ln) was missing and for more efficent code I joined int to the output
		System.out.println("The int is " +num1);
		//Typo printing this also the '9' included, also attached double variable to the end of output
		System.out.println("The double is " +num2);
	}

}
