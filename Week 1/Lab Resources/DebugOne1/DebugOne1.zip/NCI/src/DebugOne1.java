/*
 * DebugOne1
 * C Musitongo
 * 21 Jan 2025
 * 
 *  Debugging exercise, changed the formatting and rewrote the main method and added missing curly brackets
 *  (I think they're called perenthesis?)*/

public class DebugOne1 {

	/* This program displays a greeting */
	public static void main(String[] args) {
		
		System.out.println("Hello.");
		
	}
}
